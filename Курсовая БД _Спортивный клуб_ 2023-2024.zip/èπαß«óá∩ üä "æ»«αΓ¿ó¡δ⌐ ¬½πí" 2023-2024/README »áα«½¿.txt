Пользователь: MainAdmin1
Пароль: Qwerty123

Пользователь: Customer1
Пароль: Qwerty123

Пользователь: Customer2
Пароль: Qwerty123

Пользователь: Customer3
Пароль: Qwerty123

Пользователь: Customer4
Пароль: Qwerty123

Пользователь: Customer5
Пароль: Qwerty123