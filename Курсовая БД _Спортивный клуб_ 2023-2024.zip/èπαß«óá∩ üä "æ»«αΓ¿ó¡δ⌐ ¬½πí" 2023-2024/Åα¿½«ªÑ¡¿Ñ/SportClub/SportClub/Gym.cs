﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportClub
{
    public partial class Gym : Form
    {
        public Gym()
        {
            InitializeComponent();
        }

        private void gymBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try { 
            this.Validate();
            this.gymBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.sportClubDataSet);
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void Gym_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "sportClubDataSet.Gym". При необходимости она может быть перемещена или удалена.
            this.gymTableAdapter.Fill(this.sportClubDataSet.Gym);

        }

        string fileImage = "";

        private void buttonOpenPhoto_Click(object sender, EventArgs e)
        {

            openFileDialogPhoto.Title = "Укажите файл для фото";
            if (openFileDialogPhoto.ShowDialog() == DialogResult.OK)
            {
                fileImage = openFileDialogPhoto.FileName;
                try
                {
                    photoPictureBox.Image = new
                   Bitmap(openFileDialogPhoto.FileName);
                }
                catch
                {
                    MessageBox.Show("Выбран не тот формат файла", "Ошибка",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            else fileImage = "";
        }

        private static Gym gm;
        public static Gym gym
        {
            get
            {
                if (gm == null || gm.IsDisposed) gm = new Gym();
                return gm;
            }
        }

        public void ShowForm()
        {
            Show();
            Activate();
        }
    }
}
