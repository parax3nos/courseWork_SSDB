﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportClub
{
    public partial class Note : Form
    {
        public Note()
        {
            InitializeComponent();
        }

        private void noteBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.noteBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.sportClubDataSet);
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void Note_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "sportClubDataSet.Note". При необходимости она может быть перемещена или удалена.
            this.noteTableAdapter.Fill(this.sportClubDataSet.Note);

        }

        private static Note nt;
        public static Note note
        {
            get
            {
                if (nt == null || nt.IsDisposed) nt = new Note();
                return nt;
            }
        }

        public void ShowForm()
        {
            Show();
            Activate();
        }

         string GetSelectedFieldName()
        {
            return noteDataGridView.Columns[noteDataGridView.CurrentCell.ColumnIndex].DataPropertyName;
        }
        private void toolStripButtonFind_Click(object sender, EventArgs e)
        {
            if (toolStripTextBoxFind.Text == "")
            {
                MessageBox.Show("Вы ничего не задали", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int indexPos;

            try
            {
                indexPos = noteBindingSource.Find(GetSelectedFieldName(), toolStripTextBoxFind.Text);
            }
            catch (Exception err)
            {
                MessageBox.Show("Ошибка поиска \n" + err.Message);
                return;
            }

            if (indexPos > -1)
                noteBindingSource.Position = indexPos;
            else
            {
                MessageBox.Show("Таких сотрудников нет", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                noteBindingSource.Position = 0;
            }
        }

        private void checkBoxFind_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxFind.Checked)
            {
                if (toolStripTextBoxFind.Text == "")
                    MessageBox.Show("Вы ничего не задали", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    try
                    {
                        noteBindingSource.Filter = GetSelectedFieldName() + "='" + toolStripTextBoxFind.Text + "'";
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show("Ошибка фильтрации \n" +
                       err.Message);
                    }
            }
            else
                noteBindingSource.Filter = "";
            if (noteBindingSource.Count == 0)
            {
                MessageBox.Show("Нет таких");
                noteBindingSource.Filter = "";
                checkBoxFind.Checked = false;
            }
        }
    }
}
