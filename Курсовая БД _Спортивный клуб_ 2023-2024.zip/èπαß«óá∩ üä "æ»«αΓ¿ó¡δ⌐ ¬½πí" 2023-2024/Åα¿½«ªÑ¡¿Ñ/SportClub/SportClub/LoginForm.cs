﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Security.Cryptography;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace SportClub
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            this.textBoxPass.AutoSize = false;
            this.textBoxPass.Size = new Size(this.textBoxPass.Size.Width, 70);
        }
        private void LoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = MessageBox.Show("Вы хотите закрыть программу?", "Внимание", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes;
        }

        private void buttonEnter_Click(object sender, EventArgs e)
        {

            try
            {
                string login = Convert.ToString(textBoxLogin.Text);
                string password = Convert.ToString(textBoxPass.Text);
                string connString = $"Data Source=DESKTOP-0VCJS1R;Initial Catalog=SportClub;USER Id={login};Password={password}";
                SqlConnection conn = new SqlConnection(connString);
                conn.Open();
                if (comboBoxRole.Text == "MainAdmin" & login.Contains("MainAdmin"))
                {
                    MainAdminForm form = new MainAdminForm();
                    this.Hide();
                    var formMain = new MainAdminForm();
                    formMain.Closed += (s, args) => this.Close();
                    formMain.Show();
                }
                else if (comboBoxRole.Text == "Customer" & login.Contains("Customer"))
                {
                    CustomerForm form = new CustomerForm(textBoxLogin.Text, textBoxPass.Text);
                    this.Hide();
                    var formMain = new CustomerForm(textBoxLogin.Text, textBoxPass.Text);
                    formMain.Closed += (s, args) => this.Close();
                    formMain.Show();
                }
                else
                {
                    MessageBox.Show("Роль не выбрана или выбрана неправильно");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Неправильный логин или пароль\n" + $"Возникло исключение {ex.Message}");
            }
        }

    }
}
