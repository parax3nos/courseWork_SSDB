﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportClub
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }

        private void customerBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try { 
            this.Validate();
            this.customerBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.sportClubDataSet);
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void Customer_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "usersDataSet.users". При необходимости она может быть перемещена или удалена.
            // TODO: данная строка кода позволяет загрузить данные в таблицу "sportClubDataSet.Customer". При необходимости она может быть перемещена или удалена.
            this.customerTableAdapter.Fill(this.sportClubDataSet.Customer);

        }

        private static Customer cust;
        public static Customer customer
        {
            get
            {
                if (cust == null || cust.IsDisposed) cust = new Customer();
                return cust;
            }
        }

        public void ShowForm()
        {
            Show();
            Activate();
        }


        string GetSelectedFieldName()
        {
            return customerDataGridView.Columns[customerDataGridView.CurrentCell.ColumnIndex].DataPropertyName;
        }
        private void toolStripButtonFind_Click(object sender, EventArgs e)
        {
            if (toolStripTextBoxFind.Text == "")
            {
                MessageBox.Show("Вы ничего не задали", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int indexPos;

            try 
            {
                indexPos = customerBindingSource.Find(GetSelectedFieldName(),toolStripTextBoxFind.Text);
            }
            catch (Exception err)
            {
                MessageBox.Show("Ошибка поиска \n" + err.Message);
                return;
            }

            if (indexPos > -1)
                customerBindingSource.Position = indexPos;
            else
            {
                MessageBox.Show("Таких клиентов нет", "Внимание",MessageBoxButtons.OK, MessageBoxIcon.Information);
                customerBindingSource.Position = 0;
            }
        }

        private void checkBoxFind_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxFind.Checked)
            {
                if (toolStripTextBoxFind.Text == "")
                    MessageBox.Show("Вы ничего не задали", "Внимание",MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    try
                    {
                        customerBindingSource.Filter = GetSelectedFieldName() + "='" + toolStripTextBoxFind.Text + "'";
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show("Ошибка фильтрации \n" +
                       err.Message);
                    }
            }
            else  
                customerBindingSource.Filter = "";
                if (customerBindingSource.Count == 0)
                {
                    MessageBox.Show("Нет таких");
                    customerBindingSource.Filter = "";
                    checkBoxFind.Checked = false;
                }
        }
    }
}
