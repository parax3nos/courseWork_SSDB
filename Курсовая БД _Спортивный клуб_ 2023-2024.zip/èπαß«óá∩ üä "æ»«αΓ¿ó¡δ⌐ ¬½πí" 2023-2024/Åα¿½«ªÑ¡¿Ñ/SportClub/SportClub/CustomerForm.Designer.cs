﻿namespace SportClub
{
    partial class CustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.sportClubDataSet = new SportClub.SportClubDataSet();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customerTableAdapter = new SportClub.SportClubDataSetTableAdapters.CustomerTableAdapter();
            this.tableAdapterManager = new SportClub.SportClubDataSetTableAdapters.TableAdapterManager();
            this.employeeTableAdapter = new SportClub.SportClubDataSetTableAdapters.EmployeeTableAdapter();
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customerToEmployeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gymBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.priceListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.noteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customerToEmployeeTableAdapter = new SportClub.SportClubDataSetTableAdapters.CustomerToEmployeeTableAdapter();
            this.gymTableAdapter = new SportClub.SportClubDataSetTableAdapters.GymTableAdapter();
            this.priceListTableAdapter = new SportClub.SportClubDataSetTableAdapters.PriceListTableAdapter();
            this.noteTableAdapter = new SportClub.SportClubDataSetTableAdapters.NoteTableAdapter();
            this.for_CustomerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.for_CustomerTableAdapter = new SportClub.SportClubDataSetTableAdapters.for_CustomerTableAdapter();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.buttonPriceList = new System.Windows.Forms.Button();
            this.buttonGym = new System.Windows.Forms.Button();
            this.buttonTrener = new System.Windows.Forms.Button();
            this.buttonCustomer = new System.Windows.Forms.Button();
            this.buttonNote = new System.Windows.Forms.Button();
            this.dataGridViewCustomer = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.sportClubDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerToEmployeeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.priceListBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.noteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.for_CustomerBindingSource)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCustomer)).BeginInit();
            this.SuspendLayout();
            // 
            // sportClubDataSet
            // 
            this.sportClubDataSet.DataSetName = "SportClubDataSet";
            this.sportClubDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "Customer";
            this.customerBindingSource.DataSource = this.sportClubDataSet;
            // 
            // customerTableAdapter
            // 
            this.customerTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CustomerTableAdapter = this.customerTableAdapter;
            this.tableAdapterManager.EmployeeTableAdapter = this.employeeTableAdapter;
            this.tableAdapterManager.GymTableAdapter = null;
            this.tableAdapterManager.NoteTableAdapter = null;
            this.tableAdapterManager.PriceListTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = SportClub.SportClubDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // employeeTableAdapter
            // 
            this.employeeTableAdapter.ClearBeforeFill = true;
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataMember = "Employee";
            this.employeeBindingSource.DataSource = this.sportClubDataSet;
            // 
            // customerToEmployeeBindingSource
            // 
            this.customerToEmployeeBindingSource.DataMember = "CustomerToEmployee";
            this.customerToEmployeeBindingSource.DataSource = this.sportClubDataSet;
            // 
            // gymBindingSource
            // 
            this.gymBindingSource.DataMember = "Gym";
            this.gymBindingSource.DataSource = this.sportClubDataSet;
            // 
            // priceListBindingSource
            // 
            this.priceListBindingSource.DataMember = "PriceList";
            this.priceListBindingSource.DataSource = this.sportClubDataSet;
            // 
            // noteBindingSource
            // 
            this.noteBindingSource.DataMember = "Note";
            this.noteBindingSource.DataSource = this.sportClubDataSet;
            // 
            // customerToEmployeeTableAdapter
            // 
            this.customerToEmployeeTableAdapter.ClearBeforeFill = true;
            // 
            // gymTableAdapter
            // 
            this.gymTableAdapter.ClearBeforeFill = true;
            // 
            // priceListTableAdapter
            // 
            this.priceListTableAdapter.ClearBeforeFill = true;
            // 
            // noteTableAdapter
            // 
            this.noteTableAdapter.ClearBeforeFill = true;
            // 
            // for_CustomerBindingSource
            // 
            this.for_CustomerBindingSource.DataMember = "for_Customer";
            this.for_CustomerBindingSource.DataSource = this.sportClubDataSet;
            // 
            // for_CustomerTableAdapter
            // 
            this.for_CustomerTableAdapter.ClearBeforeFill = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(995, 564);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.BackColor = System.Drawing.Color.Coral;
            this.tabPage1.Controls.Add(this.buttonPriceList);
            this.tabPage1.Controls.Add(this.buttonGym);
            this.tabPage1.Controls.Add(this.buttonTrener);
            this.tabPage1.Controls.Add(this.buttonCustomer);
            this.tabPage1.Controls.Add(this.buttonNote);
            this.tabPage1.Controls.Add(this.dataGridViewCustomer);
            this.tabPage1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(987, 538);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Customer";
            // 
            // buttonPriceList
            // 
            this.buttonPriceList.BackColor = System.Drawing.Color.Chartreuse;
            this.buttonPriceList.FlatAppearance.BorderSize = 0;
            this.buttonPriceList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPriceList.Font = new System.Drawing.Font("Microsoft JhengHei", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonPriceList.Location = new System.Drawing.Point(802, 15);
            this.buttonPriceList.Name = "buttonPriceList";
            this.buttonPriceList.Size = new System.Drawing.Size(168, 50);
            this.buttonPriceList.TabIndex = 5;
            this.buttonPriceList.Text = "УСЛУГИ";
            this.buttonPriceList.UseVisualStyleBackColor = false;
            this.buttonPriceList.Click += new System.EventHandler(this.buttonPriceList_Click);
            // 
            // buttonGym
            // 
            this.buttonGym.BackColor = System.Drawing.Color.Chartreuse;
            this.buttonGym.FlatAppearance.BorderSize = 0;
            this.buttonGym.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonGym.Font = new System.Drawing.Font("Microsoft JhengHei", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonGym.Location = new System.Drawing.Point(614, 15);
            this.buttonGym.Name = "buttonGym";
            this.buttonGym.Size = new System.Drawing.Size(168, 50);
            this.buttonGym.TabIndex = 4;
            this.buttonGym.Text = "ЗАЛЫ";
            this.buttonGym.UseVisualStyleBackColor = false;
            this.buttonGym.Click += new System.EventHandler(this.buttonGym_Click);
            // 
            // buttonTrener
            // 
            this.buttonTrener.BackColor = System.Drawing.Color.Chartreuse;
            this.buttonTrener.FlatAppearance.BorderSize = 0;
            this.buttonTrener.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTrener.Font = new System.Drawing.Font("Microsoft JhengHei", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonTrener.Location = new System.Drawing.Point(426, 15);
            this.buttonTrener.Name = "buttonTrener";
            this.buttonTrener.Size = new System.Drawing.Size(168, 50);
            this.buttonTrener.TabIndex = 3;
            this.buttonTrener.Text = "ТРЕНЕРА";
            this.buttonTrener.UseVisualStyleBackColor = false;
            this.buttonTrener.Click += new System.EventHandler(this.buttonTrener_Click);
            // 
            // buttonCustomer
            // 
            this.buttonCustomer.BackColor = System.Drawing.Color.Chartreuse;
            this.buttonCustomer.FlatAppearance.BorderSize = 0;
            this.buttonCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCustomer.Font = new System.Drawing.Font("Microsoft JhengHei", 15F, System.Drawing.FontStyle.Bold);
            this.buttonCustomer.Location = new System.Drawing.Point(15, 15);
            this.buttonCustomer.Name = "buttonCustomer";
            this.buttonCustomer.Size = new System.Drawing.Size(168, 50);
            this.buttonCustomer.TabIndex = 1;
            this.buttonCustomer.Text = "МОЯ ЗАПИСЬ";
            this.buttonCustomer.UseVisualStyleBackColor = false;
            this.buttonCustomer.Click += new System.EventHandler(this.buttonCustomer_Click);
            // 
            // buttonNote
            // 
            this.buttonNote.BackColor = System.Drawing.Color.Chartreuse;
            this.buttonNote.FlatAppearance.BorderSize = 0;
            this.buttonNote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonNote.Font = new System.Drawing.Font("Microsoft JhengHei", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonNote.Location = new System.Drawing.Point(202, 15);
            this.buttonNote.Name = "buttonNote";
            this.buttonNote.Size = new System.Drawing.Size(204, 50);
            this.buttonNote.TabIndex = 2;
            this.buttonNote.Text = "МОИ ТРЕНИРОВКИ";
            this.buttonNote.UseVisualStyleBackColor = false;
            this.buttonNote.Click += new System.EventHandler(this.buttonNote_Click);
            // 
            // dataGridViewCustomer
            // 
            this.dataGridViewCustomer.AllowUserToAddRows = false;
            this.dataGridViewCustomer.AllowUserToDeleteRows = false;
            this.dataGridViewCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCustomer.Location = new System.Drawing.Point(3, 82);
            this.dataGridViewCustomer.Name = "dataGridViewCustomer";
            this.dataGridViewCustomer.ReadOnly = true;
            this.dataGridViewCustomer.Size = new System.Drawing.Size(981, 453);
            this.dataGridViewCustomer.TabIndex = 0;
            this.dataGridViewCustomer.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewCustomer_CellClick);
            // 
            // CustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(995, 564);
            this.Controls.Add(this.tabControl1);
            this.Name = "CustomerForm";
            this.Text = "CustomerForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CustomerForm_FormClosing);
            this.Load += new System.EventHandler(this.CustomerForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sportClubDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerToEmployeeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.priceListBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.noteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.for_CustomerBindingSource)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCustomer)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private SportClubDataSet sportClubDataSet;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private SportClubDataSetTableAdapters.CustomerTableAdapter customerTableAdapter;
        private SportClubDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private SportClubDataSetTableAdapters.EmployeeTableAdapter employeeTableAdapter;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private System.Windows.Forms.BindingSource customerToEmployeeBindingSource;
        private SportClubDataSetTableAdapters.CustomerToEmployeeTableAdapter customerToEmployeeTableAdapter;
        private System.Windows.Forms.BindingSource gymBindingSource;
        private SportClubDataSetTableAdapters.GymTableAdapter gymTableAdapter;
        private System.Windows.Forms.BindingSource priceListBindingSource;
        private SportClubDataSetTableAdapters.PriceListTableAdapter priceListTableAdapter;
        private System.Windows.Forms.BindingSource noteBindingSource;
        private SportClubDataSetTableAdapters.NoteTableAdapter noteTableAdapter;
        private System.Windows.Forms.BindingSource for_CustomerBindingSource;
        private SportClubDataSetTableAdapters.for_CustomerTableAdapter for_CustomerTableAdapter;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button buttonPriceList;
        private System.Windows.Forms.Button buttonGym;
        private System.Windows.Forms.Button buttonTrener;
        private System.Windows.Forms.Button buttonCustomer;
        private System.Windows.Forms.Button buttonNote;
        private System.Windows.Forms.DataGridView dataGridViewCustomer;
    }
}