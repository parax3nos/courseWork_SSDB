﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportClub
{
    public partial class MainAdminForm : Form
    {

        public MainAdminForm()
        {
            InitializeComponent();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = MessageBox.Show("Вы хотите закрыть программу?", "Внимание", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes;   
        }

        private void buttonAboutProgramm_Click(object sender, EventArgs e)
        {
            MessageBox.Show("(C)ТУСУР,КИБЭВС,Мурзин Евгений Александрович,721-1,2023-2024", "О программе", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void buttonGym_Click(object sender, EventArgs e)
        {
            Gym.gym.ShowForm();
        }

        private void buttonTrener_Click(object sender, EventArgs e)
        {
            Employee.employee.ShowForm();
        }

        private void buttonCustomer_Click(object sender, EventArgs e)
        {
            Customer.customer.ShowForm();
        }

        private void buttonPriceList_Click(object sender, EventArgs e)
        {
            PriceList.pricelist.ShowForm();
        }

        private void buttonNote_Click(object sender, EventArgs e)
        {
            Note.note.ShowForm();
        }

        private void buttonDetailedForm_Click(object sender, EventArgs e)
        {
            DetailedForm.detailform.ShowForm();
        }

    }
}
