﻿namespace SportClub
{
    partial class MainAdminForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainAdminForm));
            this.buttonGym = new System.Windows.Forms.Button();
            this.buttonTrener = new System.Windows.Forms.Button();
            this.buttonPriceList = new System.Windows.Forms.Button();
            this.buttonCustomer = new System.Windows.Forms.Button();
            this.buttonNote = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonAboutProgramm = new System.Windows.Forms.Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonDetailedForm = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonGym
            // 
            this.buttonGym.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(244)))), ((int)(((byte)(241)))));
            this.buttonGym.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonGym.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonGym.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.buttonGym.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(185)))), ((int)(((byte)(164)))));
            this.buttonGym.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonGym.Font = new System.Drawing.Font("Microsoft JhengHei", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonGym.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(155)))), ((int)(((byte)(61)))));
            this.buttonGym.Location = new System.Drawing.Point(368, 171);
            this.buttonGym.Name = "buttonGym";
            this.buttonGym.Size = new System.Drawing.Size(200, 60);
            this.buttonGym.TabIndex = 0;
            this.buttonGym.Text = "ЗАЛЫ";
            this.buttonGym.UseVisualStyleBackColor = false;
            this.buttonGym.Click += new System.EventHandler(this.buttonGym_Click);
            // 
            // buttonTrener
            // 
            this.buttonTrener.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(244)))), ((int)(((byte)(241)))));
            this.buttonTrener.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTrener.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonTrener.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.buttonTrener.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(185)))), ((int)(((byte)(164)))));
            this.buttonTrener.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTrener.Font = new System.Drawing.Font("Microsoft JhengHei", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonTrener.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(155)))), ((int)(((byte)(61)))));
            this.buttonTrener.Location = new System.Drawing.Point(368, 95);
            this.buttonTrener.Name = "buttonTrener";
            this.buttonTrener.Size = new System.Drawing.Size(200, 60);
            this.buttonTrener.TabIndex = 5;
            this.buttonTrener.Text = "СОТРУДНИКИ";
            this.buttonTrener.UseVisualStyleBackColor = false;
            this.buttonTrener.Click += new System.EventHandler(this.buttonTrener_Click);
            // 
            // buttonPriceList
            // 
            this.buttonPriceList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(244)))), ((int)(((byte)(241)))));
            this.buttonPriceList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonPriceList.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonPriceList.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.buttonPriceList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(185)))), ((int)(((byte)(164)))));
            this.buttonPriceList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPriceList.Font = new System.Drawing.Font("Microsoft JhengHei", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonPriceList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(155)))), ((int)(((byte)(61)))));
            this.buttonPriceList.Location = new System.Drawing.Point(368, 247);
            this.buttonPriceList.Name = "buttonPriceList";
            this.buttonPriceList.Size = new System.Drawing.Size(200, 60);
            this.buttonPriceList.TabIndex = 6;
            this.buttonPriceList.Text = "УСЛУГИ";
            this.buttonPriceList.UseVisualStyleBackColor = false;
            this.buttonPriceList.Click += new System.EventHandler(this.buttonPriceList_Click);
            // 
            // buttonCustomer
            // 
            this.buttonCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCustomer.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.buttonCustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(244)))), ((int)(((byte)(241)))));
            this.buttonCustomer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonCustomer.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonCustomer.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.buttonCustomer.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(185)))), ((int)(((byte)(164)))));
            this.buttonCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCustomer.Font = new System.Drawing.Font("Microsoft JhengHei", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonCustomer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(155)))), ((int)(((byte)(61)))));
            this.buttonCustomer.Location = new System.Drawing.Point(368, 19);
            this.buttonCustomer.Name = "buttonCustomer";
            this.buttonCustomer.Size = new System.Drawing.Size(200, 60);
            this.buttonCustomer.TabIndex = 7;
            this.buttonCustomer.Text = "КЛИЕНТЫ";
            this.buttonCustomer.UseVisualStyleBackColor = false;
            this.buttonCustomer.Click += new System.EventHandler(this.buttonCustomer_Click);
            // 
            // buttonNote
            // 
            this.buttonNote.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(244)))), ((int)(((byte)(241)))));
            this.buttonNote.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonNote.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonNote.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.buttonNote.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(185)))), ((int)(((byte)(164)))));
            this.buttonNote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonNote.Font = new System.Drawing.Font("Microsoft JhengHei", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonNote.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(155)))), ((int)(((byte)(61)))));
            this.buttonNote.Location = new System.Drawing.Point(368, 323);
            this.buttonNote.Name = "buttonNote";
            this.buttonNote.Padding = new System.Windows.Forms.Padding(2);
            this.buttonNote.Size = new System.Drawing.Size(200, 60);
            this.buttonNote.TabIndex = 8;
            this.buttonNote.Text = "ЗАПИСИ";
            this.buttonNote.UseVisualStyleBackColor = false;
            this.buttonNote.Click += new System.EventHandler(this.buttonNote_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(195)))), ((int)(((byte)(237)))));
            this.buttonExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonExit.FlatAppearance.BorderSize = 0;
            this.buttonExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(72)))), ((int)(((byte)(238)))));
            this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExit.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.buttonExit.Location = new System.Drawing.Point(512, 436);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(121, 38);
            this.buttonExit.TabIndex = 9;
            this.buttonExit.Text = "ВЫХОД";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonAboutProgramm
            // 
            this.buttonAboutProgramm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(195)))), ((int)(((byte)(237)))));
            this.buttonAboutProgramm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAboutProgramm.FlatAppearance.BorderSize = 0;
            this.buttonAboutProgramm.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(98)))), ((int)(((byte)(100)))), ((int)(((byte)(208)))));
            this.buttonAboutProgramm.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(204)))));
            this.buttonAboutProgramm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAboutProgramm.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.buttonAboutProgramm.Location = new System.Drawing.Point(12, 436);
            this.buttonAboutProgramm.Name = "buttonAboutProgramm";
            this.buttonAboutProgramm.Size = new System.Drawing.Size(121, 38);
            this.buttonAboutProgramm.TabIndex = 10;
            this.buttonAboutProgramm.Text = "О ПРОГРАММЕ";
            this.buttonAboutProgramm.UseVisualStyleBackColor = false;
            this.buttonAboutProgramm.Click += new System.EventHandler(this.buttonAboutProgramm_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::SportClub.Properties.Resources.fitness_club;
            this.pictureBox6.Location = new System.Drawing.Point(12, 12);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(252, 229);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 21;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::SportClub.Properties.Resources.note;
            this.pictureBox5.Location = new System.Drawing.Point(302, 323);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(60, 60);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 20;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::SportClub.Properties.Resources.pricelist;
            this.pictureBox4.Location = new System.Drawing.Point(302, 247);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(60, 60);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 19;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.Image = global::SportClub.Properties.Resources.gym;
            this.pictureBox3.Location = new System.Drawing.Point(302, 171);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(60, 60);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 18;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Image = global::SportClub.Properties.Resources.уьздщнуу;
            this.pictureBox2.Location = new System.Drawing.Point(302, 95);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(60, 60);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 17;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SportClub.Properties.Resources.client;
            this.pictureBox1.Location = new System.Drawing.Point(302, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(60, 60);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // buttonDetailedForm
            // 
            this.buttonDetailedForm.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDetailedForm.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.buttonDetailedForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(244)))), ((int)(((byte)(241)))));
            this.buttonDetailedForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonDetailedForm.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonDetailedForm.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Cyan;
            this.buttonDetailedForm.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(185)))), ((int)(((byte)(164)))));
            this.buttonDetailedForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDetailedForm.Font = new System.Drawing.Font("Microsoft JhengHei", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonDetailedForm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(155)))), ((int)(((byte)(61)))));
            this.buttonDetailedForm.Location = new System.Drawing.Point(12, 273);
            this.buttonDetailedForm.Name = "buttonDetailedForm";
            this.buttonDetailedForm.Size = new System.Drawing.Size(252, 95);
            this.buttonDetailedForm.TabIndex = 22;
            this.buttonDetailedForm.Text = "ПОДРОБНАЯ \r\nИНФОРМАЦИЯ";
            this.buttonDetailedForm.UseVisualStyleBackColor = false;
            this.buttonDetailedForm.Click += new System.EventHandler(this.buttonDetailedForm_Click);
            // 
            // MainAdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(645, 486);
            this.Controls.Add(this.buttonDetailedForm);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonAboutProgramm);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonNote);
            this.Controls.Add(this.buttonCustomer);
            this.Controls.Add(this.buttonPriceList);
            this.Controls.Add(this.buttonTrener);
            this.Controls.Add(this.buttonGym);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainAdminForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Спортивный клуб \"TRENER\"";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonGym;
        private System.Windows.Forms.Button buttonTrener;
        private System.Windows.Forms.Button buttonPriceList;
        private System.Windows.Forms.Button buttonCustomer;
        private System.Windows.Forms.Button buttonNote;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonAboutProgramm;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button buttonDetailedForm;
    }
}

