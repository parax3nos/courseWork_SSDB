﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportClub
{
    public partial class CustomerForm : Form
    {
        string login1;
        string password1;
        public CustomerForm(string login, string password)
        {
            InitializeComponent();
            this.login1 = login;
            this.password1 = password;
        }



        private void customerBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.customerBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.sportClubDataSet);

        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "sportClubDataSet.Note". При необходимости она может быть перемещена или удалена.
            this.noteTableAdapter.Fill(this.sportClubDataSet.Note);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "sportClubDataSet.PriceList". При необходимости она может быть перемещена или удалена.
            this.priceListTableAdapter.Fill(this.sportClubDataSet.PriceList);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "sportClubDataSet.Gym". При необходимости она может быть перемещена или удалена.
            this.gymTableAdapter.Fill(this.sportClubDataSet.Gym);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "sportClubDataSet.CustomerToEmployee". При необходимости она может быть перемещена или удалена.
            this.customerToEmployeeTableAdapter.Fill(this.sportClubDataSet.CustomerToEmployee);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "sportClubDataSet.Employee". При необходимости она может быть перемещена или удалена.
            this.employeeTableAdapter.Fill(this.sportClubDataSet.Employee);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "sportClubDataSet.Customer". При необходимости она может быть перемещена или удалена.
            this.customerTableAdapter.Fill(this.sportClubDataSet.Customer);
        }
        DataTable FillDataGridView(string sqlSelect)
        {
            string connString = $"Data Source=DESKTOP-0VCJS1R;Initial Catalog=SportClub;USER Id={login1};Password={password1}";

            SqlConnection connection = new SqlConnection(connString);
            SqlCommand command = connection.CreateCommand();
            command.CommandText = sqlSelect;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        private void buttonCustomer_Click(object sender, EventArgs e)
        {
            dataGridViewCustomer.DataSource = FillDataGridView(@"Select*from Customer");
        }

        private void buttonNote_Click(object sender, EventArgs e)
        {
            dataGridViewCustomer.DataSource = FillDataGridView(@"Select*from Note");
        }

        private void buttonTrener_Click(object sender, EventArgs e)
        {
            dataGridViewCustomer.DataSource = FillDataGridView(@"select * from CustomerToEmployee");
        }

        private void buttonGym_Click(object sender, EventArgs e)
        {
            dataGridViewCustomer.DataSource = FillDataGridView(@"select * from Gym");
        }

        private void buttonPriceList_Click(object sender, EventArgs e)
        {
            dataGridViewCustomer.DataSource = FillDataGridView(@"select Id_service, Id_gym, NameService, 
PriceList.Id_employee, CustomerToEmployee.Surname, CustomerToEmployee.Name, Price from PriceList, CustomerToEmployee where CustomerToEmployee.Id_employee = PriceList.Id_employee");
        }

        private void CustomerForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = MessageBox.Show("Вы хотите закрыть программу?", "Внимание", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes;
        }

        private void dataGridViewCustomer_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
