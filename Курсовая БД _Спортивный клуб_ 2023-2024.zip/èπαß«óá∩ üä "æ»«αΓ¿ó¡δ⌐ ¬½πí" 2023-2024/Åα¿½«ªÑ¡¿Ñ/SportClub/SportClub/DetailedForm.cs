﻿using System;   
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SportClub
{
    public partial class DetailedForm : Form
    {
        DataBase db = new DataBase();
        public DetailedForm()
        {
            InitializeComponent();
        }

        private static DetailedForm dldf;
        public static DetailedForm detailform
        {
            get
            {
                if (dldf == null || dldf.IsDisposed) dldf = new DetailedForm();
                return dldf;
            }
        }

        public void ShowForm()
        {
            Show();
            Activate();
        }

        private void buttonTrener_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBoxSurname.Text))
            {
                MessageBox.Show("Обязательно укажите либо фамилию, либо идентификатор необходимого сотрудника.\nДопустим ввод первых символов.", "Внимание", MessageBoxButtons.OK,
               MessageBoxIcon.Warning);
                return;
            }
            string sqlSelect = "";

            if (radioButtonTrener.Checked)
                sqlSelect = $"select Note.Id_note as 'ID записи', note.Id_customer as 'ID клиента', Customer.Surname as 'Фамилия клиента', Customer.Name as 'Имя клиента', " +
                    $"PriceList.NameService as 'Наименование услуги', \r\nnote.SalePrice as 'Цена продажи',note.SaleDate as 'Дата продажи',Employee.Id_employee as " +
                    $"'ID работника', Employee.Surname as 'Фамилия работника' from note \r\ninner Join PriceList on PriceList.Id_service = Note.Id_service inner " +
                    $"join Employee on PriceList.Id_employee = Employee.Id_employee \r\ninner join Customer on Note.Id_customer = Customer.Id_customer " +
                    $"where Employee.Surname like @Surname";
            else if (radioButtonCustomer.Checked)
                sqlSelect = $"select Note.Id_note as 'ID записи', Employee.Id_employee as 'ID работника', Employee.Surname as 'Фамилия работника', PriceList.NameService " +
                    $"as 'Наименование услуги', \r\nnote.SalePrice as 'Цена продажи',note.SaleDate as 'Дата продажи', note.Id_customer as 'ID клиента', Customer.Surname " +
                    $"as 'Фамилия клиента', Customer.Name as 'Имя клиента'\r\nfrom note \r\ninner Join PriceList on PriceList.Id_service = Note.Id_service inner " +
                    $"join Employee on PriceList.Id_employee = Employee.Id_employee \r\ninner join Customer on Note.Id_customer = Customer.Id_customer " +
                    $"where Customer.Surname like @Surname";
            else
            {
                MessageBox.Show("Не выбран вид запроса", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            SqlCommand command = new SqlCommand(sqlSelect, db.getConnection());
            SqlParameter SurnameParam = new SqlParameter("@Surname", textBoxSurname.Text + "%");
            command.Parameters.Add(SurnameParam);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridViewMain.DataSource = table;
            if (table.Rows.Count == 0) MessageBox.Show("Нет значений!", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void textBoxID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

